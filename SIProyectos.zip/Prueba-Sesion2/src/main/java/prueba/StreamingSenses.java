package prueba;

import java.util.Properties;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;

public class StreamingSenses {

	public static Double getScore(String line) throws Exception {
		Long textLength = 0L;
		int sumOfValues = 0;
		Properties props = new Properties();
		props.setProperty("annotators", "tokenize, ssplit, parse, sentiment");
		StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
		if (line != null && line.length() > 0) {
			int longest = 0;
			Annotation anotation = pipeline.process(line);
			for (CoreMap sentence : anotation.get(CoreAnnotations.SentencesAnnotation.class)) {
				Tree tree = sentence.get(SentimentCoreAnnotations.SentimentAnnotatedTree.class);
				int sentiment = RNNCoreAnnotations.getPredictedClass(tree);
				String partText = sentence.toString();
				if (partText.length() > longest) {
					textLength += partText.length();
					sumOfValues = sumOfValues + sentiment * partText.length();
				}
			}
		}
		return (double) sumOfValues / textLength;
	}

}
